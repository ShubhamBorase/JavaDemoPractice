
import java.io.*;

class Table3{
	public static void main(String...args){

		int i = 2;

		for(int row = 1; row<=10; row++){
			System.out.print(i+" ");
			i = i+2;
		}
	}
}
