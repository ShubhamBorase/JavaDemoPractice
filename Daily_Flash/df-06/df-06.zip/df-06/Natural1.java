

class Natural1{
	public static void main (String...args){

		int nat = 1;

		System.out.println("First Ten Natural Numbers are");

		for(nat = 1; nat<11; nat++){
			System.out.println(nat);
		}
	}
}
