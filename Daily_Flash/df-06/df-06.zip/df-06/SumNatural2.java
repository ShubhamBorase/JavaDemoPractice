

class SumNatural2{
	public static void main(String...args){

		int sum = 0;

		for(int nat = 1; nat<11; nat++){
			sum = sum+nat;
		}

		System.out.println(" Sum of First Ten Natural Numbers is "+sum);
	}
}
