

class Even4{
	public static void main(String...args){

		int count = 2;

		for(int num = 1; num<51; num++){
			System.out.print(count+"  ");
			count = count+2;
		}
	}
}
