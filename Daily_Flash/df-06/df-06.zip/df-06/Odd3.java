

class Odd3{
	public static void main(String...args){

		int count = 1;

		for(int row = 1; row<51; row++){
			System.out.print(count+" ");
			count = count+2;
		}
	}
}
